let timer=1500, interval=null;
function calcular(){const v=document.getElementById('calc').value;const out=document.getElementById('resultado');if(!/^[0-9+\-*/(). %]+$/.test(v)){out.textContent='Digite uma conta válida.';return}try{out.textContent='Resultado: '+Function('return '+v)()}catch{out.textContent='Não foi possível calcular.'}}
const perguntas=[{q:'Qual é o planeta conhecido como Planeta Vermelho?',o:['Marte','Vênus','Júpiter'],a:0},{q:'Quanto é 8 × 7?',o:['54','56','64'],a:1},{q:'Qual é o maior oceano?',o:['Atlântico','Índico','Pacífico'],a:2}];
function novoQuiz(){const x=perguntas[Math.floor(Math.random()*perguntas.length)];document.getElementById('quizPergunta').textContent=x.q;const box=document.getElementById('quizOpcoes');box.innerHTML='';x.o.forEach((op,i)=>{const b=document.createElement('button');b.textContent=op;b.onclick=()=>document.getElementById('quizPergunta').textContent=i===x.a?'✅ Acertou!':'❌ Tente novamente!';box.appendChild(b)})}
function renderTimer(){const m=String(Math.floor(timer/60)).padStart(2,'0'),s=String(timer%60).padStart(2,'0');document.getElementById('timer').textContent=m+':'+s}
function iniciarTimer(){if(interval)return;interval=setInterval(()=>{if(timer>0){timer--;renderTimer()}else pararTimer()},1000)}
function pararTimer(){clearInterval(interval);interval=null}
function resetTimer(){pararTimer();timer=1500;renderTimer()}
function converter(){const m=Number(document.getElementById('metros').value);document.getElementById('conversao').textContent=Number.isFinite(m)?`${m} m = ${m*100} cm = ${m/1000} km`:''}
document.getElementById('themeBtn').onclick=()=>{document.body.classList.toggle('light');document.getElementById('themeBtn').textContent=document.body.classList.contains('light')?'🌙':'☀️'}
renderTimer();
